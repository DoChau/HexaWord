const s=!0,a=!1;export{s as b,a as d};
