module.exports = {
  plugins: {
    autoprefixer: {},
    tailwindcss: {},
  },
}
