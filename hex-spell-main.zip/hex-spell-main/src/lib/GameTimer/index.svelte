<script>
  export let timer
</script>

<section class="text-2xl">
  Timer: { timer }
</section>
