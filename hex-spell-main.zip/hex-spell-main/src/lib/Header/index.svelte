<header>
	<nav class="flex justify-between border-b border-black bg-neutral">
		<a href="/" class="hover:bg-selected"><h1 class="p-3 text-2xl text-title uppercase">Hex-Spell</h1></a>
		<!-- <a href="/login" class="p-3 text-2xl hover:bg-selected">Login</a> -->
	</nav>
</header>
